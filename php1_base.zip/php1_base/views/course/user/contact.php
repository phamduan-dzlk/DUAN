<div class="container">
    <a href="<?=BASE_URL?>" class="btn btn-secondary mb-3">← Trở lại</a>
</div>
